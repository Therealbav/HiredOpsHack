RU :
1. Отключаем антивирус.
1. Запускаем игру.
2. Запускаем Loader.ехе от имени администратора.
3. Вводим ключ активации в поле License key.
4. После авторизации попадаем в окно инжектора и нажимаем INJECТ HACK.
6. Наслаждаемся игрой!

VAC задетектил метод обхода, как будет время сделаю новый, поэтому сейчас ИГРАЙТЕ НА ТВИНКЕ!!! После получение бана, игровых ограничений нет и игру можно продолжить на этом же аккаунте с ВАКОМ. 
______________________

EN:
1. Disable the antivirus.
1. Launch the game.
2. Launch Loader.exe as administrator.
3. Enter the activation key in the License key field.
4. After authorization, go to the injector window and click INJECT HACK.
6. Enjoy the game!

VAC has detected a bypass method, when there is time to make a new one, so now PLAY ON TWINK!!! After receiving a ban, the slot is blocked and the game can be continued on the same account with VAC. 