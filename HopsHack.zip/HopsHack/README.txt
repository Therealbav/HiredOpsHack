RU :
1. Отключаем антивирус.
1. Запускаем игру.
2. Запускаем Loader.ехе от имени администратора.
3. Вводим ключ активации в поле License key.
4. После авторизации попадаем в окно лоадера, он будет ожидать запуск игры с надписью "WAIT GAME" и заинжектит чит после запуска игры с надписью "INJECTION". Если игра уже запущена, он сразу начнет инжектить чит. Что запускать первым, игру или лоадер - не принципиально. 
5. Открыть/закрыть меню чита в игре DELETE. Отгрузить чит из игры INSERT.
6. Наслаждаемся игрой!

Обход античитов: VAC, SABECLAW.
Телеграмм канал: https://t.me/DarthonChanel
_________________________

EN:
1. Disable the antivirus.
1. Launch the game.
2. Launch Loader.exe as administrator.
3. Enter the activation key in the License key field.
4. After authorization, we get to the loader window, it will wait for the game to launch with the inscription "WAIT GAME" and will inject the cheat after the game launches with the inscription "INJECTION". If the game is already running, it will immediately start injecting the cheat. What to launch first, the game or the loader, is not important.
5. Open/close the cheat menu in the game DELETE. Unload the cheat from the game INSERT.
6. Enjoy the game!

Bypass anti-cheats: VAC, SABECLAW.
Telegram channel: https://t.me/DarthonChanel